import Axios from 'axios';

Axios.defaults.baseURL = 'http://localhost:3000';

export default{
    getAllBooks(){
        return Axios.get('/books')
            .then(resp => {
                console.log(resp.data);
                return resp.data;
            })
            .catch(err =>{
                console.log(err);
            })
    },
    getBookById(id){
        return Axios.get(`/books/${id}`)
            .then(resp => {
                console.log(resp.data);
                return resp.data;
            })
            .catch(err =>{
                console.log(err);
            })
    }
}