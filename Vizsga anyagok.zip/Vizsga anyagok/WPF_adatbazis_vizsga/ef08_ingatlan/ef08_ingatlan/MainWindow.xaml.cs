﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.EntityFrameworkCore;
using ef08_ingatlan.Models;

namespace ef08_ingatlan
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ingatlanContext contex = new ingatlanContext();

        public MainWindow()
        {
            InitializeComponent();

            contex.Sellers.Load();
            contex.Realestates.Load();

            LBO_seller.ItemsSource = contex.Sellers.Local.ToObservableCollection();

            this.DataContext = contex.Sellers.Local.ToObservableCollection();
        }

        private void BTN_hirdetesekBetoltese_Click(object sender, RoutedEventArgs e)
        {
            LB_hirdetesekSzama.Content = (from r in contex.Realestates.Local
                                          where r.SellerId == ((Seller)LBO_seller.SelectedItem).Id
                                          select r).Count();
        }
    }
}
