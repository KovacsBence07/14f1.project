<template>
  <div class="row mt-3">
    <div class="col-12">
      <h1 class="text-center">Konyv reszletek</h1>
    </div>
    <div class="card mb-3 mx-auto" style="max-width: 540px;">
      <div class="row g-0">
        <div class="col-md-4">
          <img :src="egyKonyv.imagelink" class="img-fluid rounded-start" :alt="egyKonyv.title" />
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <h5 class="card-title">{{egyKonyv.title}}</h5>
            <p
              class="card-text"
            ><strong>Author: {{egyKonyv.author}}</strong><br>
            <strong>Country:{{egyKonyv.country}}</strong><br>
             <strong>Language:{{egyKonyv.language}}</strong><br>
              <strong>Pages:{{egyKonyv.pages}}</strong><br>
               <strong>Year:{{egyKonyv.year}}</strong><br>
                <strong>Wiki:</strong>
                    <a :href="egyKonyv.link" target="_blank">{{egyKonyv.link}}</a>
                </p>
            <p class="card-text">
              <router-link to="/tablazat" class="btn btn-outline-primary float-end mb-2">Vissza</router-link>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DataService from '../services/dataservice'

export default {
    name:'reszletek',
    data(){
        return{
            egyKonyv:{},
        }
    },
    created(){
        DataService.getBookById(this.$route.params.id)
            .then(resp =>{
                this.egyKonyv = resp;
            })
    }
};
</script>

<style>
</style>