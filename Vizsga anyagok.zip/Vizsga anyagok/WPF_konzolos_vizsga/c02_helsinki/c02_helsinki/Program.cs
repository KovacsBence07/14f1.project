﻿using System;
using System.Collections.Generic;
using System.IO;

namespace c02_helsinki
{
    class Helyezes
    {
        public int hely;
        public int sportolokSzama;
        public string sportag;
        public string versenySzam;

        public Helyezes(string sor)
        {
            string[] adatok = sor.Split(' ');
            hely = int.Parse(adatok[0]);
            sportolokSzama = int.Parse(adatok[1]);
            sportag = adatok[2];
            versenySzam = adatok[3];
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Helyezes> helyezesek = new List<Helyezes>();
            foreach (var sor in File.ReadAllLines("helsinki.txt"))
            {
                helyezesek.Add(new Helyezes(sor));
            }

            Console.WriteLine("3. feladat:");
            Console.WriteLine("Pontszerző helyek száma: {0}",helyezesek.Count);

            int arany = 0;
            int ezust = 0;
            int bronz = 0;
            foreach (var egyHelyezes in helyezesek)
            {
                if (egyHelyezes.hely == 1) arany++;
                if (egyHelyezes.hely == 2) ezust++;
                if (egyHelyezes.hely == 3) bronz++;
            }
            Console.WriteLine("4. feladat:");
            Console.WriteLine("Arany: {0}",arany);
            Console.WriteLine("Ezüst: {0}",ezust);
            Console.WriteLine("Bronz: {0}",bronz);
            Console.WriteLine("Összesen: {0}",arany+ezust+bronz);


            int olimpiaiPontok = 0;
            foreach (var egyHelyezes in helyezesek)
            {
                if (egyHelyezes.hely == 1) olimpiaiPontok += 7;
                if (egyHelyezes.hely == 2) olimpiaiPontok += 5;
                if (egyHelyezes.hely == 3) olimpiaiPontok += 4;
                if (egyHelyezes.hely == 4) olimpiaiPontok += 3;
                if (egyHelyezes.hely == 5) olimpiaiPontok += 2;
                if (egyHelyezes.hely == 6) olimpiaiPontok += 1;
            }
            Console.WriteLine("5. feladat:");
            Console.WriteLine("Olimpiai pontok száma: {0}",olimpiaiPontok);

            int eremUszas = 0;
            int eremTorna = 0;
            foreach (var egyHelyezes in helyezesek)
            {
                if (egyHelyezes.hely < 4 && egyHelyezes.sportag == "uszas") eremUszas++;
                if (egyHelyezes.hely < 4 && egyHelyezes.sportag == "torna") eremTorna++;
            }

            if (eremTorna == eremUszas)
            {
                Console.WriteLine("Egyenlő volt az érmék száma");
            } else
            {
                if (eremTorna > eremUszas)
                {
                    Console.WriteLine("A torna sportágban szereztek több érmet.");
                } else
                {
                    Console.WriteLine("A úszás sportágban szereztek több érmet.");
                }
            }

            List<string> kiiras = new List<string>();
            foreach (var egyHelyezes in helyezesek)
            {
                if (egyHelyezes.sportag == "kajakkenu")
                {
                    egyHelyezes.sportag = "kajak-kenu";
                }
                kiiras.Add(
                    string.Format("{0} {1} {2} {3}",
                    egyHelyezes.hely,
                    egyHelyezes.sportolokSzama,
                    egyHelyezes.sportag,
                    egyHelyezes.versenySzam)
                    );
            }

            File.WriteAllLines("helsinki2.txt", kiiras);
        }
    }
}
