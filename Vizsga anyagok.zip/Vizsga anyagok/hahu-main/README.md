# hahu minta project
0. Ha nincs telepitve express-generator akkor // npm i -g express-generator
1. cmd-ben: express --no-view projectname
2. cd projectname
3. npm install
4. nodemon telepitese npm i --save nodemon, majd a start script szerekesztese ("start": "nodemon ./bin/www")
5. mongoose telepitese npm i --save mongoose

//git config --global user.email "you@example.com"
//git config --global user.name "Your Name"

A 2. feladat: Adatbazis letrehozasa
1. Lokalis mongoDB szerver elinditasa: cmd ben: mongod parancs kiadasa (abblakot nem szabad becsukni)
2. A compass-ban beirjuk a szerver url-jet: mongodb://127.0.0.1:27017
3. adatbazis es collectionok importalasa letrehozasa
4. model mappa letrehozasa majd a tablak .js fajlba levo letrehozasa



