import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Tablazat from '../views/Tablazat.vue'
import Reszletek from '../views/Reszletek.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path:'/tablazat',
    component: Tablazat
  },
  {
    path: '/reszletek/:id',
    component: Reszletek
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
